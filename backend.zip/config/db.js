const mongoose = require('mongoose');

let connectionAttempts = 0;

const connectWithRetry = async () => {
  const maxDelayMs = 30000;
  const baseDelayMs = 3000;
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`🟢 MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    connectionAttempts += 1;
    const backoff = Math.min(maxDelayMs, baseDelayMs * connectionAttempts);
    console.error(`❌ MongoDB connection failed (attempt ${connectionAttempts}): ${error.message}`);
    console.error(`⏳ Retrying in ${Math.round(backoff / 1000)}s...`);
    setTimeout(connectWithRetry, backoff);
  }
};

const connectDB = async () => {
  // Start connection attempts without exiting the app
  connectWithRetry();
};

const isDbConnected = () => mongoose.connection.readyState === 1;

module.exports = connectDB;
module.exports.isDbConnected = isDbConnected;
