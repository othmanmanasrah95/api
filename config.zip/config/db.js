const mongoose = require('mongoose');

let connectionAttempts = 0;
let lastConnectionError = null;

// Helpful map of mongoose ready states
const READY_STATE = {
  0: 'disconnected',
  1: 'connected',
  2: 'connecting',
  3: 'disconnecting'
};

// Attach connection event listeners once
mongoose.connection.on('connected', () => {
  lastConnectionError = null;
  console.log('🟢 MongoDB connected');
});

mongoose.connection.on('error', (err) => {
  lastConnectionError = err;
  console.error('❌ MongoDB connection error:', err.message);
});

mongoose.connection.on('disconnected', () => {
  console.warn('⚠️  MongoDB disconnected');
});

/**
 * Establish a MongoDB connection and resolve only when connected.
 * Retries up to a limited number of attempts with incremental backoff.
 */
const connectDB = async () => {
  if (mongoose.connection.readyState === 1) {
    return;
  }

  const maxAttempts = 5;
  const baseDelayMs = 2000;

  while (connectionAttempts < maxAttempts) {
    try {
      connectionAttempts += 1;
      const conn = await mongoose.connect(process.env.MONGO_URI);
      console.log(`🟢 MongoDB Connected: ${conn.connection.host}`);
      return;
    } catch (error) {
      lastConnectionError = error;
      const backoff = baseDelayMs * connectionAttempts;
      console.error(`❌ MongoDB connection failed (attempt ${connectionAttempts}/${maxAttempts}): ${error.message}`);
      if (connectionAttempts >= maxAttempts) {
        console.error('🛑 Giving up after maximum connection attempts');
        throw error;
      }
      console.error(`⏳ Retrying in ${Math.round(backoff / 1000)}s...`);
      await new Promise((r) => setTimeout(r, backoff));
    }
  }
};

const isDbConnected = () => mongoose.connection.readyState === 1;

const getDbStatus = () => {
  const state = mongoose.connection.readyState;
  return {
    connected: state === 1,
    state,
    stateName: READY_STATE[state] || 'unknown',
    error: lastConnectionError ? lastConnectionError.message : null
  };
};

module.exports = { connectDB, isDbConnected, getDbStatus };